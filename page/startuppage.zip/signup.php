<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <script>
        
        function validatePassword() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirm_password").value;

            
            if (password.length < 8) {
                alert("Password must be at least 8 characters long.");
                return false;
            }

          
            var specialCharacters = /[!@#$%^&*()\-_=+{}[\]|\\;:'"<>,./?]/g;
            if (!password.match(specialCharacters)) {
                alert("Password must contain at least one special character (!@#$%^&*()-_=+{}[]|\;:'\"<>,./?)");
                return false;
            }

           
            var upperCaseLetters = /[A-Z]/g;
            if (!password.match(upperCaseLetters)) {
                alert("Password must contain at least one uppercase letter.");
                return false;
            }

          
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <h2>Sign Up</h2>

    <?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $conn = new mysqli("localhost", "effism", "admin", "login_page");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "INSERT INTO user_detail (name, email, user, password) VALUES ('$name', '$email', '$username', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('New record created successfully. Redirecting to login page...'); window.location.href='login.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }
    ?>

    <form action="signup.php" method="POST" onsubmit="return validatePassword()">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required><br><br>
        <input type="submit" value="Sign Up">
    </form>
    <br>
    <button onclick="window.location.href='login.php'">Login</button>
</body>
</html>
