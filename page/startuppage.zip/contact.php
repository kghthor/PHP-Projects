<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

function sanitizeForCSV($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitizeForCSV($_POST['name']);
    $email = sanitizeForCSV($_POST['email']);
    $message = sanitizeForCSV($_POST['message']);

    
    $csvFile = '/var/www/html/page/contacts.csv';

    
    $file = fopen($csvFile, 'a');

    if (!$file) {
        die("Error opening file: " . error_get_last()['message']);
    }

    
    fputcsv($file, array($name, $email, $message));


    fclose($file);

   
    echo "Message sent successfully.";

   
    header("Location: contacts.php");
    exit();
}


$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
    <style>
        .container {
            display: flex;
        }
        .user-details, .logout-btn, .contact-form {
            flex: 1;
            padding: 20px;
            border-radius: 10px;
        }
        .user-details {
            background-color: #f0f0f0;
        }
        .contact-form {
            background-color: #e0e0e0;
        }
        .logout-btn {
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body>
   
    <div class="container" >
        <div class="user-details">
            <h3>User Details</h3>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($user['user']); ?></p>
        </div>
       
        <div class="contact-form" method="POST">
        <h2>Contact Us</h2>
            <h3>Send Us a Message</h3>
            <form action="contact.php" method="POST">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required><br><br>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br><br>
                <label for="message">Message:</label>
                <textarea id="message" name="message" required></textarea><br><br>
                <input type="submit" value="Send Message">
            </form>
        </div>
    </div>
    <div class="logout-btn">
        <form action="logout.php" method="POST">
            <input type="submit" value="Logout">
        </form>
    </div>
</body>
</html>
